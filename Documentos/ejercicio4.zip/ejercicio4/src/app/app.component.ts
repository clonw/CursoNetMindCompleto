import { Component } from '@angular/core';
import {ResultadosService} from './resultados.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  array;
  constructor(  private _resultadosService: ResultadosService ) {
    this.array = this._resultadosService.getData().toPromise();
  }

}
