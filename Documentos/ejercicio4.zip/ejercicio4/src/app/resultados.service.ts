import { Injectable } from '@angular/core';
import {catchError} from 'rxjs/operators';
import {Observable} from 'rxjs';
import { HttpClient, HttpHeaders, HttpClientModule } from '@angular/common/http';
import {Resultado} from './resultado';

@Injectable({
  providedIn: 'root'
})
export class ResultadosService {
  url = 'https://cursosdedesarrollo.com/pactometro/resultados.json';
  constructor(private _http: HttpClient) { }
  getData() {
    return this._http.get<Observable<Resultado[]>>(this.url).pipe(catchError(this.handleError('get', [])));
  }
  // maneja el error
  private handleError (operation = 'operation', result?) {
    return (error: any): any[] => {
      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead
      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);
      // Let the app keep running by returning an empty result.
      return [];
    };
  }
}
