export class Resultado {
  constructor(
    public nombre: string = '',
    public dipu: number = 0,
    public imagen: string = ''
  ) {

  }
}
