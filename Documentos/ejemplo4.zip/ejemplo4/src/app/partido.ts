export class Partido {
 nombre: string;
 dipu: number;
 imagen:string;
}