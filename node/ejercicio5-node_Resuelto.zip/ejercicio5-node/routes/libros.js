var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
  var array=[
      {
          id:req.params.id,
          isbn:1234567890123,
          titulo:"El señor de los anillos",
          autor:"J.R.R. Tolkien",
          sinopsis:"Orcos chungos quieren gobernar el mundo gracias a un ojo"
      },
      {
          id:req.params.id,
          isbn:1234567890124,
          titulo:"Las dos Torres",
          autor:"J.R.R. Tolkien",
          sinopsis:"Boromir palma"
      },
      {
          id:req.params.id,
          isbn:1234567890125,
          titulo:"El retorno del Rey",
          autor:"J.R.R. Tolkien",
          sinopsis:"Bienvenidos los semielfos"
      }
  ];
  res.setHeader('Content-Type', 'application/json');
  res.send(JSON.stringify(array));
});

router.get('/:id', function(req, res, next) {
    res.setHeader('Content-Type', 'application/json');
    console.log(req.params.id);
    var objetoLibro={
        id:req.params.id,
        isbn:1234567890123,
        titulo:"El señor de los anillos",
        autor:"J.R.R. Tolkien",
        sinopsis:"Orcos chungos quieren gobernar el mundo gracias a un ojo"
    };
    res.send(JSON.stringify(objetoLibro));
});


router.post('/', function(req, res, next) {
    res.setHeader('Content-Type', 'application/json');
    // console.log(req.body);
    req.body.id=12;
    res.send(JSON.stringify(req.body));
});
router.post('/edit/:id', function(req, res, next) {
    res.setHeader('Content-Type', 'application/json');
    // console.log(req.body);
    req.body.id=req.params.id;
    res.send(JSON.stringify(req.body));
});
router.get('/delete/:id', function(req, res, next) {
    res.setHeader('Content-Type', 'application/json');
    console.log(req.params.id);
    var objetoLibro={
        id:req.params.id,
        isbn:1234567890123,
        titulo:"El señor de los anillos",
        autor:"J.R.R. Tolkien",
        sinopsis:"Orcos chungos quieren gobernar el mundo gracias a un ojo"
    };
    res.send(JSON.stringify(objetoLibro));
});

module.exports = router;
